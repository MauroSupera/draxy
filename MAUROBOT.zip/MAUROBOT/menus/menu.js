const menu = (prefix, NomeDoBot) => {
  
// NÃO APAGUE ESSE ${NickDono} nem 
//${numerodn} nem ${NomeDoBot} nem ${prefix} só se quiser apagar completo, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.  
  
return `​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​
     ╭══• ೋ•✧๑💎๑✧•ೋ •══╮ 
                      ${NomeDoBot} 
                 🔥 𝙢𝙚𝙣𝙪༒𝙧𝙖́𝙥𝙞𝙙𝙤🔥
    ╰══• ೋ•✧๑💎๑✧•ೋ •══╯  
╭─╼━══━━≺ 🥂 ≻━━══━╾─╮
╎☆ۣۜۜ͜͡ 💎 ${prefix}menu2
╎
╎☆ۣۜۜ͜͡ 🔥 ${prefix}Brincadeiras 
╎
╎☆ۣۜۜ͜͡ 💎 ${prefix}Alteradores 
╎
╎☆ۣۜۜ͜͡ 🔥 ${prefix}Menuadm 
╎
╎☆ۣۜۜ͜͡ 💎 ${prefix}Menudono 
╎
╎☆ۣۜۜ͜͡ 🔥 ${prefix}Efeitosimg 
╎  
╎☆ۣۜۜ͜͡ 💎 ${prefix}level
╎
╎☆ۣۜۜ͜͡ 🔥 ${prefix}Logos 
╎
╎☆ۣۜۜ͜͡ 💎 ${prefix}status
╎
╎☆ۣۜۜ͜͡ 🔥 ${prefix}infodono
╎
╎☆ۣۜۜ͜͡ 💎 ${prefix}ping
╎
╎☆ۣۜۜ͜͡ 🔥 ${prefix}Menupremium
╎
╎☆ۣۜۜ͜͡ 💎 ${prefix}perfil  
╰─╼━══━━≺ 👑 ≻━━══━╾─╯

              𝅘𝅥𝅮𝙋𝙚𝙨𝙦𝙪𝙞𝙨𝙖𝙧 𝙚 𝘽𝙖𝙞𝙭𝙖𝙧𝅘𝅥𝅮        
╭─╼━══━━≺ 🥂 ≻━━══━╾─╮
╎☆ۣۜۜ͜͡ 📱 ${prefix}ytb (algo do youtube)
╎
╎☆ۣۜۜ͜͡ 🎸 ${prefix}Play (NOME)
╎
╎☆ۣۜۜ͜͡ 🎬 ${prefix}Playmp4 (NOME)
╎
╎☆ۣۜۜ͜͡ 🎧 ${prefix}Ytsearch (NOME)
╎
╎☆ۣۜۜ͜͡ 🎵 ${prefix}Ytmp4 (LINNOM
╎
╎☆ۣۜۜ͜͡ 🎺 ${prefix}Ytmp3 (LINK)
╎
╎☆ۣۜۜ͜͡ 🎻 ${prefix}tiktok (LINK)
╎
╎☆ۣۜۜ͜͡ 🥁 ${prefix}Instadw (LINK)
╎
╎☆ۣۜۜ͜͡ 🎶 ${prefix}Twitter (LINK)
╎
╎☆ۣۜۜ͜͡  🎙${prefix}Imgpralink (MARCAR)                    
╎
╎☆ۣۜۜ͜͡ 🎤 ${prefix}Videopralink (MARCAR-V)
╰─╼━══━━≺ 🧸 ≻━━══━╾─╯

        🪄  𝙛𝙞𝙜𝙪𝙧𝙞𝙣𝙝𝙖𝙨 𝙚 𝙎𝙩𝙞𝙘𝙠𝙚𝙧𝙨 🪄        
╭─╼━══━━≺ 🥂 ≻━━══━╾─╮
╎☆ۣۜۜ͜͡ 🔮 ${prefix}Attp (TEXTO)
╎
╎☆ۣۜۜ͜͡ 🪄 ${prefix}Attp2 (TEXTO)
╎   
╎☆ۣۜۜ͜͡ 🔮 ${prefix}emoji2 ou emojimix (😇+😈)
╎
╎☆ۣۜۜ͜͡ 🪄 ${prefix}Ttp (TEXTO)
╎
╎☆ۣۜۜ͜͡ 🔮 ${prefix}Fsticker (MARCAR-FOTO)
╎
╎☆ۣۜۜ͜͡ 🪄 ${prefix}Sticker (MARCAR-FOTO)
╎
╎☆ۣۜۜ͜͡ 🔮 ${prefix}Toimg (MARCAR-FIGU)
╎
╎☆ۣۜۜ͜͡ 🪄 ${prefix}Togif (MARCAR-FIGU)
╎
╎☆ۣۜۜ͜͡ 🔮 ${prefix}Roubar (TEXT/TEXT)
╰─╼━══━━≺ 🌙 ≻━━══━╾─╯

                       🎲𝙂𝙖𝙢𝙚𝙨 🎮            
╭─╼━══━━≺ 🥂 ≻━━══━╾─╮
╎☆ۣۜۜ͜͡ 🎮 ${prefix}Ppt (JOKENPÔ)
╎
╎☆ۣۜۜ͜͡ 🎮 ${prefix}Jogodavelha (@MARCAR)
╎
╎☆ۣۜۜ͜͡ 🎮 ${prefix}Ttt (JOGO-DA-VELHA) 
╎
╎☆ۣۜۜ͜͡ 🎮 ${prefix}Cassino
╎
╎☆ۣۜۜ͜͡ 🎮 ${prefix}Quizanime 1 / 0
╎
╎☆ۣۜۜ͜͡ 🎮 ${prefix}Quizanimais 1 / 0
╎
╎☆ۣۜۜ͜͡ 🎮 ${prefix}Anagrama 1 / 0
╰─╼━══━━≺ 🎡 ≻━━══━╾─╯

    🥱𝙁𝙪𝙣𝙘̧𝙤̃𝙚𝙨 𝘿𝙤 𝘽𝙤𝙩 𝙚 𝙈𝙚𝙢𝙗𝙧𝙤𝙨🥱
╭─╼━══━━≺ 🥂 ≻━━══━╾─╮
╎☆ۣۜۜ͜͡ 🥷 ${prefix}celular (nome do cll)
╎
╎☆ۣۜۜ͜͡🥷 ${prefix}playstore (Nome do app)
╎
╎☆ۣۜۜ͜͡ 🥷 ${prefix}Ping (VELO)
╎
╎☆ۣۜۜ͜͡ 🥷 ${prefix}Atividade
╎
╎☆ۣۜۜ͜͡ 🥷 ${prefix}Rankativ
╎
╎☆ۣۜۜ͜͡ 🥷${prefix}correio (exemplo @5512978986457/saudades'-')
╎
╎☆ۣۜۜ͜͡ 🥷 ${prefix}Checkativo (@MARCAR)
╎
╎☆ۣۜۜ͜͡ 🥷 ${prefix}Ranklevel (DE-TODOS)
╰─╼━══━━≺ 💞 ≻━━══━╾─╯        
 
            🤪𝗙𝘂𝗻𝗰̧𝗼̃𝗲𝘀 𝗔𝗹𝗲𝗮𝘁𝗼́𝗿𝗶𝗮𝘀🤪
╭─╼━══━━≺ 🥂 ≻━━══━╾─╮
╎☆ۣۜۜ͜͡ 🍭 ${prefix}Gtts (LINGUAGEM + TEXTO)
╎
╎☆ۣۜۜ͜͡ 🍭 ${prefix}Tagme
╎
╎☆ۣۜۜ͜͡ 🍭 ${prefix}Emoji
╎
╎☆ۣۜۜ͜͡ 🍭 ${prefix}Tabela (LETRAS)
╎
╎☆ۣۜۜ͜͡ 🍭 ${prefix}Conselhobiblico
╎
╎☆ۣۜۜ͜͡ 🍭 ${prefix}Simi (FALE-ALGO)
╎
╎☆ۣۜۜ͜͡ 🍭 ${prefix}Frases
╎
╎☆ۣۜۜ͜͡ 🍭 ${prefix}Calcular (1 + 1)
╎
╎☆ۣۜۜ͜͡ 🍭 ${prefix}Fazernick (NICK)
╎
╎☆ۣۜۜ͜͡ 🍭 ${prefix}Bot
╎ 
╎☆ۣۜۜ͜͡ 🍭  ${prefix}sakura
╰─╼━══━━≺ 💖 ≻━━══━╾─╯

`
}

exports.menu = menu

// NÃO APAGUE ESSE ${NickDono} nem 
//${numerodn} nem ${NomeDoBot} nem ${prefix} só se quiser apagar completo, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.