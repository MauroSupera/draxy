const menuprem = (prefix) => { 

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

return `
╭══• ೋ•✧๑💎๑✧•ೋ •══╮ 
      ঔৣ͜͡ீ͜❥͜ 𝐌𝐄𝐍𝐔ツ𝐏𝐑𝐄𝐌𝐈𝐔𝐌ू ፝͜❥
╰══• ೋ•✧๑🥋๑✧•ೋ •══╯ 
╭─╼━══━≺♤≻━━══━╾╮   
╎☆ۣۜۜ͜͡  🥋 ${prefix}Delete(Bot deleta ╎(algo)💎
╎☆ۣۜۜ͜͡  🔥 ${prefix}Destrava💎
╎☆ۣۜۜ͜͡  🥋${prefix}Destrava2💎
╎☆ۣۜۜ͜͡  🔥 ${prefix}DDD (numero)💎
╎☆ۣۜۜ͜͡  🥋 ${prefix}Cep (numero)💎
╎☆ۣۜۜ͜͡  🔥 ${prefix}Gerarcpf💎
╎☆ۣۜۜ͜͡  🥋 ${prefix}Premiumlist💎
╎☆ۣۜۜ͜͡  🔥 ${prefix}Lerfoto (marca)💎   
╎☆ۣۜۜ͜͡  🥋 ${prefix}Encurtalink (link)💎   
╰─╼━═━━≺♤≻━━══━╾╯
`
}

exports.menuprem = menuprem