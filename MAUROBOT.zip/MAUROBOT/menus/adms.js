const adms = (prefix) => { 

 

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

	return `​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​

╭══• ೋ•✧๑🌙๑✧•ೋ •══╮
           💎𝑴𝑬𝑵𝑼 𝑫𝑶𝑺 𝑨𝑫𝑴💎
╰══• ೋ•✧๑☕๑✧•ೋ•══╯     
╭─╼━══━≺♤≻━━══━╾╮
╎☆ۣۜۜ͜͡ 🍹${prefix}kick[@]
╎(pra-remover) 
╎
╎☆ۣۜۜ͜͡ 🍔${prefix}ban (responder-mensagem)
╎
╎☆ۣۜۜ͜͡ 🍨${prefix}ban2 (determine um tempo)
╎
╎☆ۣۜۜ͜͡ 🌮${prefix}fechargpt (exemplo.fechargpt 1 h 10 s 30 m)
╎
╎☆ۣۜۜ͜͡ 🍦${prefix}abrirgpt (exemplo..abrirgpt 1 h, 9 s,9 m)
╎
╎☆ۣۜۜ͜͡ 🍣 ${prefix}antiporno

╎☆ۣۜۜ͜͡ 🥙${prefix}antinotas
╎
╎☆ۣۜۜ͜͡ 🍳 ${prefix}novolink
╎
╎☆ۣۜۜ͜͡ 🍧 ${prefix}reviver (marcar mensagem do element removido)
╎
╎☆ۣۜۜ͜͡ 🍩 ${prefix}add exemplo. (5512978986457)
╎
╎☆ۣۜۜ͜͡ 🌮 ${prefix}promover [@] (promover a adm)
╎
╎☆ۣۜۜ͜͡ 🍕 ${prefix}rebaixar [@] (rebaixaradm)
╎
╎☆ۣۜۜ͜͡ 🥙 ${prefix}apresentar
╎
╎☆ۣۜۜ͜͡ ☕${prefix}papof
╎
╎☆ۣۜۜ͜͡ 🥧${prefix}digt
╎
╎☆ۣۜۜ͜͡ 🥡${prefix}apr
╎
╎☆ۣۜۜ͜͡ 🍥 ${prefix}legendabv (oq qr)
╎
╎☆ۣۜۜ͜͡ 🍤 ${prefix}legendasaiu (oq qr)
╎
╎☆ۣۜۜ͜͡ 🍷 ${prefix}legendasaiu2 (oq qr)
╎
╎☆ۣۜۜ͜͡ 🍾 ${prefix}legendabv2 (o
╎
╎☆ۣۜۜ͜͡ 🍯 ${prefix}totag (menciona-algo)
╎
╎☆ۣۜۜ͜͡ 🍭 ${prefix}descriçãogp 
╎
╎☆ۣۜۜ͜͡ 🍬 ${prefix}grupo f/a
╎
╎☆ۣۜۜ͜͡ 🍫 ${prefix}nomegp (Nome)
╎
╎☆ۣۜۜ͜͡ 🥧 ${prefix}status
╎
╎☆ۣۜۜ͜͡ 🧁 ${prefix}limpar (texto-invisível-gp)
╎
╎☆ۣۜۜ͜͡ 🍰 ${prefix}atividades (DO-GRUPO)
╎
╎☆ۣۜۜ͜͡ 🍩 ${prefix}linkgp
╎
╎☆ۣۜۜ͜͡ 🎂 ${prefix}grupoinfo
╎
╎☆ۣۜۜ͜͡ 🧋 ${prefix}votação 
╎
╎☆ۣۜۜ͜͡ 🥤 ${prefix}sorteio (DESCREVA O PREMIO)
╎
╎☆ۣۜۜ͜͡ 🍪 ${prefix}hidetag (txt) (marcação)
╎
╎☆ۣۜۜ͜͡ 🍜 ${prefix}marcar (marca tds do gp)
╎
╎☆ۣۜۜ͜͡ 🍚 ${prefix}marcar2 (marca tds do gp com Wa.me/)
╎
╎☆ۣۜۜ͜͡ 🥖 ${prefix}anagrama 1 / 0
╎
╎☆ۣۜۜ͜͡ 🥜 ${prefix}antidocumento 1 / 0  
╎
╎☆ۣۜۜ͜͡ 🌰 ${prefix}antiloc 1 / 0  
╎
╎☆ۣۜۜ͜͡ 🧇 ${prefix}anticontato 1 / 0  
╎
╎☆ۣۜۜ͜͡ 🥨 ${prefix}antilink 1 / 0
╎
╎☆ۣۜۜ͜͡ 🥯 ${prefix}antilinkhard 1 / 0
╎
╎☆ۣۜۜ͜͡ 🍗 ${prefix}Antiviewonce 1 / 0
╎
╎☆ۣۜۜ͜͡ 🥞 ${prefix}antifake 1 / 0
╎
╎☆ۣۜۜ͜͡ 🧀 ${prefix}bemvindo 1 / 0
╎
╎☆ۣۜۜ͜͡ 🍮 ${prefix}antiimg 1 / 0
╎
╎☆ۣۜۜ͜͡ 🍝 ${prefix}antiaudio 1 / 0
╎
╎☆ۣۜۜ͜͡ 🍙 ${prefix}antivideo 1 / 0
╎
╎☆ۣۜۜ͜͡ 🍔 ${prefix}leveling 1 / 0  
╎
╎☆ۣۜۜ͜͡ 🥙 ${prefix}simih 1 / 0
╎
╎☆ۣۜۜ͜͡ 🫔 ${prefix}simih2 1 / 0
╎
╎☆ۣۜۜ͜͡ 🌮 ${prefix}fotogp (Marca)
╎
╎☆ۣۜۜ͜͡ 🥪 ${prefix}descgp (TXT)
╎
╎☆ۣۜۜ͜͡ 🌭 ${prefix}nomegp (Nome)
╎
╎☆ۣۜۜ͜͡ 🍕 ${prefix}criartabela (ESCREVA-ALGO)
╎
╎☆ۣۜۜ͜͡ 🍿 ${prefix}tabelagp             
╰╼━══━━≺♤≻━━══━╾╯

`
}

exports.adms = adms

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.