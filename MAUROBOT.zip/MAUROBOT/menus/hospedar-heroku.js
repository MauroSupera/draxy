const hospedar = (prefix) => {
return `

XIII SÓ NO CANAL DO MEU CRIADOR :( https://youtube.com/c/M%C3%A1rcioScheyot2004 Aproveita e se inscreve pra fazer parte da família🔥🥋

`
}

exports.hospedar = hospedar
